function start() {
    cm.warp(102000000);	
    cm.dispose();
}