/*
	NPC Name: 		Mr. Kim
	Map(s): 		Victoria Road : Lith Harbor (104000000)
	Description: 		Storage
*/
function action(mode, type, selection) {
    cm.sendStorage();
    cm.dispose();
}