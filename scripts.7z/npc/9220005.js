function start() {
    if (cm.getMapId() == 209000000) {
        cm.sendYesNo("�A�Q�n�e���B���ϰ��?");
    } else if (cm.getMapId() == 209080000) {
        cm.sendYesNo("�A�Q�n�^�h�t�Ϥ����?");
    }
}

function action(mode, type, selection) {
    if (mode > 0)
    if (cm.getMapId() == 209000000 && cm.getPlayer().hasEquipped(1472063)) {
    cm.cancelEffectFromBuffStat();
    cm.warp(209080000, 0);
    cm.dispose();
/*    } else if (cm.getMapId() == 209000000 && !cm.getPlayer().hasEquipped(1472063)) {
    cm.sendNext("�A�S���˳��]�k��M");
    cm.dispose();*/
    } else if (cm.getMapId() == 209080000) {
    cm.warp(209000000, 0);
    cm.dispose();
    }
}