var status = -1;

function start() {
    status = -1;
    action(1, 0, 0);
}

function action(mode, type, selection) {
    if (mode == 1)
	status++;
    else
	status--;
    if (status == 0 && cm.getMapId() == 925100500) {
        if (!cm.isLeader()) {
	    cm.dispose();
	    return;
        }
        cm.showEffect(true, "quest/party/clear");
        cm.playSound(true, "Party1/Clear");
	var eim = cm.getEventInstance();
	var players = eim.getPlayers();
	cm.givePartyExp(17500, players);
	var bonusmap = cm.getMap(925100600);
	for (var i = 0; i < players.size(); i++) {
            players.get(i).endPartyQuest(1204);
	    players.get(i).changeMap(bonusmap, bonusmap.getPortal(0));
	}
    } else if (status == 0 && cm.getMapId() == 925100600) {
	cm.removeAll(4001117);
	cm.removeAll(4001120);
	cm.removeAll(4001121);
	cm.removeAll(4001122);
	cm.sendSimple("�D�`���§A�̬@�ϤF�ڡI\r\n#b#L0#�ڭn���}#l\r\n#L1#�ڭn�I��������U�l#l#k");
    } else if (status == 1 && cm.getMapId() == 925100600) {
	if (selection == 0) {
	    cm.warp(251010404,0);
	} else {
	    var cmp = cm.getPlayer().getOneInfo(1204, "cmp");
	    var have0 = cm.getPlayer().getOneInfo(1204, "have0");
	    var have1 = cm.getPlayer().getOneInfo(1204, "have1");
	    var have2 = cm.getPlayer().getOneInfo(1204, "have2");
	    var have3 = cm.getPlayer().getOneInfo(1204, "have3");
	    if (cmp == null) {
		cm.sendOk("50�� = LV60���s���U�l\r\n150�� = LV70���s���U�l\r\n300�� = LV80���s���U�l\r\n500�� = LV90���s���U�l");
	    } else {
		var cmp_i = parseInt(cmp);
		var have0_i = parseInt(have0);
		var have1_i = parseInt(have1);
		var have2_i = parseInt(have2);
		var have3_i = parseInt(have3);
		if (have3_i > 0) {
		    if (cm.canHold(1002574,1)) {
		    	cm.gainItem(1002574,1);
			cm.sendOk("I have given you the hat.");
		    } else {
			cm.sendOk("I have already given you the hat,but if you want another,please make room.");
		    }
		} else if (have2_i > 0) {
		    if (cmp_i >= 500) {	
			if (cm.canHold(1002574,1)) {
		    	    cm.gainItem(1002574,1);
			    cm.sendOk("I have given you the hat.");
		    	} else {
			    cm.sendOk("Please make room.");
		        } 
		    } else {
			cm.sendOk("You need 350 Pirate PQ to get the next hat. Current : " + cmp_i);
		    }
		} else if (have1_i > 0) {
		    if (cmp_i >= 300) {	
			if (cm.canHold(1002573,1)) {
		    	    cm.gainItem(1002573,1);
			    cm.sendOk("I have given you the hat.");
		    	} else {
			    cm.sendOk("Please make room.");
		        } 
		    } else {
			cm.sendOk("You need 200 Pirate PQ to get the next hat. Current : " + cmp_i);
		    }
		} else if (have0_i > 0) {
		    if (cmp_i >= 150) {	
			if (cm.canHold(1002572,1)) {
		    	    cm.gainItem(1002572,1);
			    cm.sendOk("I have given you the hat.");
		    	} else {
			    cm.sendOk("Please make room.");
		        } 
		    } else {
			cm.sendOk("You need 80 Pirate PQ to get the next hat. Current : " + cmp_i);
		    }
		} else {
		    if (cmp_i >= 50) {	
			if (cm.canHold(1002571,1)) {
		    	    cm.gainItem(1002571,1);
			    cm.sendOk("I have given you the hat.");
		    	} else {
			    cm.sendOk("Please make room.");
		        } 
		    } else {
			cm.sendOk("You need 30 Pirate PQ to get the next hat. Current : " + cmp_i);
		    }
		}
	    }
	}
	cm.dispose();
    }
}