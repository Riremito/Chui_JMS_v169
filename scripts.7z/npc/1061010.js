function start() {
    cm.sendYesNo("�A�T�w�n�X�h��?");
}

function action(mode, type, selection) {
    if (mode == 1) {
	var map = cm.getMapId();
	var tomap;

	if (map == 108010301) {
	    tomap = 105070001;
	} else if (map == 108010201) {
	    tomap = 100040106;
	} else if (map == 108010101) {
	    tomap = 105040305;
	} else if (map == 108010401) {
	    tomap = 107000402;
	}
	cm.warp(tomap);
    }
    cm.dispose();
}
