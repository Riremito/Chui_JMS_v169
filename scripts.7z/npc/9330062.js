function start() {
    cm.warp(742000101);	
    cm.dispose();
}