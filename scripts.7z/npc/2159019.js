function action(mode, type, selection) {
    cm.sendNext("Please save me!");
    cm.dispose();
}