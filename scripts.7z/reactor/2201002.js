function act() {
    rm.spawnMonster(9300010, 0, -211);
}