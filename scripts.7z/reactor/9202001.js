/*
Guild Quest - Chained Spear
Drops the Longinus Spear (4001025)
*/

function act() {
	rm.dropItems();
}
