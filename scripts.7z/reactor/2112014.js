/* @Author Lerk
 * 
 * 2112014.js: Zakum Party Quest Giant Chest - drops a Fire Ore when 7 Keys are dropped in front of it
*/

function act() {
    rm.dropItems();
}