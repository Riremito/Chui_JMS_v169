/* 
 Berserk 4th job quest rock - Warp you away
*/

function act() {
    rm.playerMessage("You were sent out of the map due to an unknown force.");
    rm.warp(105090200, 0);
}