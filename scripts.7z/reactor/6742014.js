function act() {
	rm.dropItems(true, 2, 1000, 2000);
}