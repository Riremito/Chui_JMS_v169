function act() {
	rm.dropItems();
}
