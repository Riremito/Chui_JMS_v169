/*
Relic - 4th job Assassinate
*/

function act() {
    rm.dropItems();
}