/* @Author Lerk
 * 
 * 2302002.js: Aqua Road Reactor - Shell - Drops Air Bubbles, Orange Pots, meso
 * 
*/

function act(){
	rm.dropItems(true, 2, 55, 70);
}