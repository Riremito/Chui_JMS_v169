
function act() {
        rm.spawnMonster(9300108,3);
        rm.spawnMonster(9300109,3);
        rm.spawnMonster(9300110,3);
        rm.spawnMonster(9300111,3);
}