/*
Relic - 4th job Assassinate
*/

function act() {
    rm.spawnMonster(9300091, 1);
}