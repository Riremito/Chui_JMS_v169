/*
 Fire demond, 4th job quest rock - Drop skill book
*/

function act() {
    rm.dropItems();
}
