/*
Relic - 4th job Assassinate
*/

function act() {
    rm.warpS(910200000, 3);
}