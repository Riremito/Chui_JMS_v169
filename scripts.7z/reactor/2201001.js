function act(){
    rm.spawnMonster(9300007);
    rm.spawnMonster(9300007);
    rm.spawnMonster(9300007);
}