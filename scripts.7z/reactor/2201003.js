function act() {
    rm.spawnMonster(9300012, 1014, 184);
}