/*
Guild Quest - Protector Rock 
Drops the Protector Rock earrings necessary (normally) to stay alive in the Guild Quest
*/

function act() {
	rm.dropItems();
}