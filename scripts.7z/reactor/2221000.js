/*
KFT Reactor - Yellow King Goblin
*/

function act(){
	rm.spawnMonster(7130400);
	rm.mapMessage(5, "Here comes Yellow King Goblin!");
}