/* @Author Lerk
 * 
 * 2212002.js: Mateon Field reactors - Parts 3, Meso, White Pots
 * 
*/

function act(){
	rm.dropItems(true, 2, 80, 100);
}