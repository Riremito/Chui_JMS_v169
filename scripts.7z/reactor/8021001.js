function act() {
    rm.spawnMonster(9400261, 751, 137);
}