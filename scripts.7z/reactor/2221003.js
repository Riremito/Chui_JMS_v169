/* @Author Lerk
 * 
 * 2221003.js: KFT Reactor - Hongbu Gourd
 * Note that Gourd (should) drop both Hongbu and Nolbu's quest items; in Global you would only see the quest item that you need, 
 * and nobody would see the other unless they had the other quest started and were in your party.
*/

function act(){
	rm.spawnMonster(9500400);
}