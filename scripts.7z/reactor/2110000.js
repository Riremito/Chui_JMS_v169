/* @Author Lerk
 * 
 * 2110000.js: Zakum Party Quest Chest - action go280010000
*/

function act(){
    rm.playerMessage(5, "An unknown force has returned you to the starting point.");
    rm.warp(280010000);
}