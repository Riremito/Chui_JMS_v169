/* @Author Lerk
 * 
 * 9202004.js: Guild Quest - Pantry Box
 * Drops the Jr. Necki Wine (4001030)
 * 
*/

function act() {
	rm.dropItems();
}
