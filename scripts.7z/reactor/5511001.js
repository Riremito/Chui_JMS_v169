function act() {

    rm.spawnMonster(9420546, 1);

}