/*
Florina Beach Coconut - drops a coconut 
*/

function act() {
	rm.dropItems();
}