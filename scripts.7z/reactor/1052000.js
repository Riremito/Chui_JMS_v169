/*
 Berserk 4th job quest rock - Drop shield
*/

function act() {
    rm.dropItems();
}