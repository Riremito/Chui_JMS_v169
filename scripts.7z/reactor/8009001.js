/*
 * MAP  : Vanished village
 * FUNC : Bamboo warrior Reactor
 */

function act() {
    rm.killMonster(6090002);
}