

function act() {
    rm.dropItems();
}