function act(){
	rm.killMonster(6090000);
}