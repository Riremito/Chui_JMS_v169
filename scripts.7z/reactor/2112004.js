/* @Author Lerk
 * 
 * 2112004.js: Zakum Party Quest Chest - drops a key
*/

function act(){
    rm.dropItems();
}