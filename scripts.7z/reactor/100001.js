function act() {
	rm.doHarvest();
}