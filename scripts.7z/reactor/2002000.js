/* @Author Lerk
 * 
 * 2002000.js: Orbis Box - drops meso, orange/white pots, and Empty Potion Bottles (quest item)
*/

function act() {
	rm.dropItems(true, 2, 60, 80);
}