/* @Author Lerk
 * 
 * 2112008.js: Zakum Party Quest Rock - drops an item (elixir)
*/

function act(){
    rm.dropItems();
}