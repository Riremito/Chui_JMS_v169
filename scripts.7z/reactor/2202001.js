/* @Author Lerk
 * 
 * 2202001.js: Ludibirum Jump Quest Barrel: Drops item
*/

function act(){
	rm.dropItems();
}