/*
Leafre Reactor - Egg for Phoenix Quest (4th job Bowmaster)
*/

function act(){
	rm.spawnMonster(9300089);
}