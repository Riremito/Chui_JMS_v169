/*
Queen's Path : Forest of the Start 5
*/

function act(){
	rm.dropItems(true, 2, 8, 12, 2);
}