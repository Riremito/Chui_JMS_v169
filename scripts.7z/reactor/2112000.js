/* @Author Lerk
 * 
 * 2112000.js: Zakum Party Quest Chest - drops an item (elixir)
*/

function act(){
    rm.dropItems();
}