/*
 * 8001000.js: Zipangu: The Nightmarish Last Days
 * Summons BodyGuard A
*/

function act(){
    rm.changeMusic("Bgm06/FinalFight");
	rm.spawnMonster(9400112, 830, 160);
    rm.mapMessage("Bodyguard A is summoned.")
}