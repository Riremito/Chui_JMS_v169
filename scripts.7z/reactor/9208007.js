/*
Stage 2: Spear destinations - Guild Quest

@Author Lerk
*/

function act() {
    var r = rm.getPlayer().getEventInstance().getMapFactory().getMap(990000400).getReactorByName("speargate");
    r.forceHitReactor(r.getState() + 1);
//    rm.getPlayer().getEventInstance().getMapFactory().getMap(990000400).getReactorByName("speargate").hitReactor(rm.getClient());
}