function act() {
	rm.spawnMonster(9300049);
}