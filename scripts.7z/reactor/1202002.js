/*
Relic - Aran Find the Puppet quest
*/

function act() {
    rm.dropItems();
}