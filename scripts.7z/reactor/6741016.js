function act() {
    rm.spawnMonster(9400739,1);
}