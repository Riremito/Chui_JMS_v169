/* @Author Lerk
 * 
 * 2112011.js: Zakum Party Quest Rock - drops a key
*/

function act(){
    rm.dropItems();
}