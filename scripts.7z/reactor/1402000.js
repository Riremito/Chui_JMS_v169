function act(){
	rm.dropItems(true, 2, 8, 12, 2);
}