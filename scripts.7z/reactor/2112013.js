/* @Author Lerk
 * 
 * 2112013.js: Zakum Party Quest Rock - drops an item (~100 meso bundle in Global)
*/

function act(){
    rm.dropItems(true, 1, 125, 175);
}