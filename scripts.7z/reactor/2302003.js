/* @Author Lerk
 * 2302003.js: Aqua Road Reactor - Cauldron for Resurrection Quest (4th job Bishop)
*/

function act(){
    rm.dropItems();
}