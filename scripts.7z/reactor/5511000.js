// Targa


function act() {

    rm.spawnMonster(9420541, 1);


}