/*
 * MAP  : A Night In the Forest
 * FUNC : Bamboo warrior Reactor
 */

function act() {
    rm.killMonster(6090002);
}