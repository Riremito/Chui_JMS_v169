/*
Dragon nest
*/

function act() {
    rm.spawnNpc(2081008);
}