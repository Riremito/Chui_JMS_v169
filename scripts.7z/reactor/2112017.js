/*
Frostprey Egg in El Nath Mountains - part of the Frostprey quest (4th job Marksman)
*/

function act(){
	rm.dropItems();
}