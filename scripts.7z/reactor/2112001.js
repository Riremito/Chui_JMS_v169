/* @Author Lerk
 * 
 * 2112001.js: Zakum Party Quest Chest - drops an item (fried chicken)
*/

function act(){
    rm.dropItems();
}