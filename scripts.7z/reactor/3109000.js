function act() {
	rm.forceCompleteQuest(23120);
}