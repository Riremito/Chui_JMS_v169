/*
	Reactor: 		Blue Alchemy Pillar
	Map(s): 		Magatia
	Description: 	Drops 'regular tree branch'
*/

function act() {
	rm.dropItems();
}