/*
Zakum Party Quest Chest - drops a document
*/

function act(){
	rm.dropItems();
}