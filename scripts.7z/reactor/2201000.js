/*
Summons alternate Toy Trojans (no drops except for the Maintenance Manual quest item)
*/

function act(){
	rm.spawnMonster(9300011, 10);
}