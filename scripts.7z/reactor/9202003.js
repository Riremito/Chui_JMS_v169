/* @Author Lerk
 * 
 * 9202003.js: Guild Quest - Dining Hall Cover
 * Drops the Rotten Food (4001029)
 * 
*/

function act() {
	rm.dropItems();
}
