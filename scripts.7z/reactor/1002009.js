/*
Maple Island Box - drops various items, notably quest items Old Wooden Board and Rusty Screw
*/

function act() {
	rm.dropItems(true, 2, 8, 15);
}