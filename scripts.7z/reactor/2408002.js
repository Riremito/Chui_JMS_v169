function act() {
    if (rm.getMapId() == 240050101) {
        rm.forceStartReactor(240050100, 2402002);
    } else if (rm.getMapId() == 240050102) {
        rm.forceStartReactor(240050100, 2402003);
    } else if (rm.getMapId() == 240050103) {
        rm.forceStartReactor(240050100, 2402004);
    } else if (rm.getMapId() == 240050104) {
        rm.forceStartReactor(240050100, 2402005);
    }
}