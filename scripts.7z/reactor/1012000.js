/* @Author Lerk
 * 
 * 1012000.js: Ellinia Plant - drops meso, tree branches, red pots, and Plant Samples (quest item)
*/

function act() {
    rm.dropItems(true, 2, 20, 40);
}