/* @Author Lerk
 * 
 * 2112010.js: Zakum Party Quest Rock - drops an item (power elixir)
*/

function act(){
	rm.dropItems();
}