function act() {
    rm.spawnMonster(9400748,1);
}