function act() {
    rm.spawnMonster(9400740,1);
}