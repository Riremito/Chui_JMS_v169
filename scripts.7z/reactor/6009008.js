/*
 * FUNC : Oberon Reactor
 */

function act() {
    rm.killMonster(9420551);
}