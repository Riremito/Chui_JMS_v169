/* @Author Lerk
 * 
 * 2212003.js: Dogon's HQ reactor - Dogon's Report, Meso
 * 
*/

function act(){
	rm.dropItems(true, 2, 80, 100);
}