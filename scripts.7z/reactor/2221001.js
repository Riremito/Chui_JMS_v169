/*
KFT Reactor - Blue King Goblin
*/

function act(){
	rm.spawnMonster(7130401);
	rm.mapMessage(5, "Here comes Blue King Goblin!");
}