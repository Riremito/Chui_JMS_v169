/* 
 * spawn for Jr. Gargoyle (9300033) for Mark of Evil (4001035), Sharenian: Waterway Maze (990000630)
 * 
 * Guild Quest - part of stage 4
 */

function act(){
        rm.spawnMonster(9300033, 8, -100, 50);
}
