/* @Author SharpAceX
*/

function act() {
	rm.dropItems();
}
