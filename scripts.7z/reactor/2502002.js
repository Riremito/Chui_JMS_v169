function act(){
	rm.dropItems();
}