function act(){
	rm.playerMessage(5, "Poison Golem is spawned.");
	rm.spawnMonster(9300180,1);
}