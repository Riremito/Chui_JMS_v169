/*
Zakum Party Quest Chest - drops an item (power elixir)
*/

function act(){
	rm.dropItems();
}