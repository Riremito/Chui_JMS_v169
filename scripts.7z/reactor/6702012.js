function act() {
	rm.dropItems();
}