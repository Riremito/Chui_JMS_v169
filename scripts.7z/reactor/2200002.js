function act() {
    rm.warpMap(922010201,0);
}